from django.apps import AppConfig


class BeanieConfig(AppConfig):
    name = 'beanie'
